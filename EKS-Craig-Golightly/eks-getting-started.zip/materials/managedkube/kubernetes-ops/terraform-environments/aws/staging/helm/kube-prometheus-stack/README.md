# helm chart - kube-prometheus-stack

Chart source: https://github.com/prometheus-community/helm-charts/tree/main/charts/kube-prometheus-stack
