# How to add in a new app


If a new github repo is added, what all activities need to be done to deploy its code in production