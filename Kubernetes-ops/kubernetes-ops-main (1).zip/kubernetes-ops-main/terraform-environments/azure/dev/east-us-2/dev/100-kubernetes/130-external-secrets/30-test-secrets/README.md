# Test Secrets
This is a test file to test if this setup can pull a secret.

This is to be applied manually via `kubectl`

## Azure Vault Permissions to add in a secret
Add the following into your Azure Vault:

1. Vault IAM Role
2. Access Policies


### 1. Vault IAM Role
Grant yourself the `Key Vault Administrator` role

### 2. Access Policies
Give yourslelf all permissions
