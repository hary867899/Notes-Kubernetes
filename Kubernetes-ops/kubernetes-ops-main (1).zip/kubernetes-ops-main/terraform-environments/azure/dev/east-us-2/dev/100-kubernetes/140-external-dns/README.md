# External-DNS

Docs:
* https://github.com/kubernetes-sigs/external-dns/blob/master/docs/tutorials/azure.md

