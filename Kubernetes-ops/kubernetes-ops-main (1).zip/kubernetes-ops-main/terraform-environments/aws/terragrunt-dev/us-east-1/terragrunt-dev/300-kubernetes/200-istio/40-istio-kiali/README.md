# Istio Kiali

Docs: https://kiali.io/docs/installation/installation-guide/install-with-helm/

Helm chart: https://github.com/kiali/helm-charts/blob/master/kiali-operator

Release numbers can be found here:
* https://kiali.io/news/release-notes/
