# This is a set of pods that will generate APM metrics into the setup so that you
# can view the spans in Grafana.  There are two apps in here

# app 1: opentelemtry-example-app - this app has a frontend and a backend.  You will
# have to port forward to this app and visit the website to induce any action

# Inspired source: https://github.com/open-telemetry/opentelemetry-collector-contrib/blob/main/examples/tracing/docker-compose.yml
