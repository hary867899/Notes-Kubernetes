# EKS cluster autoscaler

source: https://github.com/terraform-aws-modules/terraform-aws-eks/tree/master/examples/irsa

Chart: https://github.com/kubernetes/autoscaler
