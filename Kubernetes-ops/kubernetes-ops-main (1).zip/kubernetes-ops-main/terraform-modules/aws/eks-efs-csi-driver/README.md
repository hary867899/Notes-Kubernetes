# EKS EFS CSI Driver

source: https://github.com/kubernetes-sigs/aws-efs-csi-driver


Creates:
* AWS IAM policies for the efs-csi-driver to access EFS
* Deploys the aws-efs-csi-driver helm chart into an EKS cluster
