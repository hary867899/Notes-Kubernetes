# External Secrets

## Creating secrets with newline
Used here for the TLS certs which has newlines in the cert file:
* https://learn.microsoft.com/en-us/azure/key-vault/secrets/multiline-secrets
