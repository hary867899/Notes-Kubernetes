# external-dns

Source chart: https://github.com/kubernetes-sigs/external-dns/tree/master/charts/external-dns
