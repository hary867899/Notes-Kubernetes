# Staging Environment
You can view [this tutorial](https://www.pluralsight.com/courses/eks-getting-started) for a complete walkthrough of setting up a staging environment in EKS using the code in this folder. 
