# peer-transit-gateway-internal

This module uses one AWS accounts (#1). 

It will peer two transit gateways together

## Assumptions

- AWS account #1 owns both of the Transit Gateway and it is already created. 

## This module will:

- 
