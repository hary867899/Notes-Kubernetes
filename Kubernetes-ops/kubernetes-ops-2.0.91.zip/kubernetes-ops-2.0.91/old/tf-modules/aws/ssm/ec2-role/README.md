EC2 SSM Role
=============

This is a required role that is created to be attached EC2 instances to give it access to SSM and the S3 bucket for the interactive session logs output.

https://docs.aws.amazon.com/systems-manager/latest/userguide/what-is-systems-manager.html
