attach-policy-to-group
========================

This module adds an AWS IAM policy to a group.
