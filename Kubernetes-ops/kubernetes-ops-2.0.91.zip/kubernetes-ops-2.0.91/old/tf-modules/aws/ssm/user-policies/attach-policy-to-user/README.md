attach-policy-to-user
=====================

This module attaches an AWS IAM policy to a list of users.
