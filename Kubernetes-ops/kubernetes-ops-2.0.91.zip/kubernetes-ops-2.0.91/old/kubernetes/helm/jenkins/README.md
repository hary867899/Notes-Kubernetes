Jenkins
============

Source Chart: https://github.com/helm/charts/tree/master/stable/jenkins
