kube-metrics-adapter
=====================

Source: https://github.com/zalando-incubator/kube-metrics-adapter

Kube Metrics Adapter is a general purpose metrics adapter for Kubernetes that can collect and serve custom and external metrics for Horizontal Pod Autoscaling.

