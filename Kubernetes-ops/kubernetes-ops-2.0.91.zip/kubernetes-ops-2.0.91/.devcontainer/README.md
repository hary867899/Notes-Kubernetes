Source: https://github.com/microsoft/vscode-remote-try-go
