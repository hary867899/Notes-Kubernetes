# Deployment

![alt text](./diagrams/x2-image-build-pipeline.jpeg "Title")

How to deploy to dev, test, pre-prod, prod??

